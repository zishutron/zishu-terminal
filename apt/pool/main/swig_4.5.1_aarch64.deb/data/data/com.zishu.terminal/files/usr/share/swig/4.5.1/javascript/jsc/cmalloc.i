%include <typemaps/cmalloc.swg>
