#!/data/data/com.zishu.terminal/files/usr/bin/sh

echo "$@"
