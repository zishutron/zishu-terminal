set(RESOLV_WRAPPER_LIBRARY /data/data/com.zishu.terminal/files/usr/lib/libresolv_wrapper.so)
